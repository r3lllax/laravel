<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'surname',
        'patronymic',
        'login',
        'password',
        'photo_file',
        'role_id',
        'api_token'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'role',
        'role_id',
        'password',
        'patronymic',
        'surname',
        'photo_file',
        'api_token',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function generateToken()
    {
        $this->update([
            'api_token' => Str::random(25)
        ]);
        return $this->api_token;
    }

    public function logout()
    {
        $this->update([
            'api_token' => null
        ]);
    }

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function hasRole($roles)
    {
        return in_array($this->role->code, $roles);
    }

    public function shiftWorkers()
    {
        return $this->hasMany(ShiftWorker::class);
    }

    public function getShiftWorker($work_shift_id)
    {
        return $this->shiftWorkers()->where(['work_shift_id' => $work_shift_id])->first();
    }
}
