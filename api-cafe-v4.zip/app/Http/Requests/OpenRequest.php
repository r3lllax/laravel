<?php

namespace App\Http\Requests;

use App\Exceptions\ApiException;
use App\Models\WorkShift;

class OpenRequest extends APIRequest
{
    public function authorize()
    {
        return !WorkShift::where(['active' => true])->first();
    }

    public function rules()
    {
        return [
            //
        ];
    }

    protected function failedAuthorization()
    {
        throw new ApiException(403, 'Forbidden. There are open shifts!');
    }
}
