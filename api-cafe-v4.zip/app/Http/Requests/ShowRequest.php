<?php

namespace App\Http\Requests;

use App\Exceptions\ApiException;

class ShowRequest extends APIRequest
{
    public function authorize()
    {
        $order = $this->route('order');
        return $order->user->id === $this->user()->id;
    }

    protected function failedAuthorization()
    {
        throw new ApiException(403, 'Forbidden. You did not accept this order!');
    }

    public function rules()
    {
        return [
            //
        ];
    }
}
