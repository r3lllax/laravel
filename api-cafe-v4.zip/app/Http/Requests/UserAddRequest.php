<?php

namespace App\Http\Requests;

use App\Exceptions\ApiException;
use App\Models\WorkShift;

class UserAddRequest extends APIRequest
{
    public function authorize()
    {
        $workShift = WorkShift::find($this->work_shift_id);

        if (!$workShift->active) {
            throw new ApiException(403, 'Forbidden. The shift must be active!');
        };

        if (!$workShift->hasUser($this->user())) {
            throw new ApiException(403, 'Forbidden. You don\'t work this shift!');
        }

        return true;
    }

    public function rules()
    {
        return [
            'name' => 'required|string',
            'surname' => 'string',
            'patronymic' => 'string',
            'login' => 'required|string|unique:users',
            'password' => 'required|string',
            'photo_file' => 'image|mimes:jpg,jpeg,png',
            'role_id' => 'required|integer|exists:users,id',
        ];
    }
}
