<?php

namespace App\Http\Requests;

use App\Models\User;

class UserLoginRequest extends APIRequest
{
    public function authorize()
    {
        if ($this->login && $this->password) {
            return User::where([
                'login'=> $this->login,
                'password'=>$this->password,
                'status'=> 'working'
            ])->first();
        }
        return true;
    }

    public function rules()
    {
        return [
            'login'=>'required|string',
            'password'=>'required|string',
        ];
    }
}
